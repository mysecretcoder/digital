# -*- coding: utf-8 -*-


class IRI:
    MAINNET_COORDINATOR = ''
